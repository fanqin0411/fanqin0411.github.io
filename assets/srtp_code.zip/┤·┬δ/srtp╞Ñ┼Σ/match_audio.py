#!/usr/bin/env python3
# match_audio_last4.py

import argparse
import numpy as np
import pandas as pd

def load_last4_features(csv_path, index_col=None):
    """
    加载音频库，只取最后四列特征。
    如果 CSV 有索引列，则用 index_col 指定该列名或列号。
    返回 (names, feats_last4)：
      names: 行索引/音频名称列表
      feats_last4: (N,4) numpy 数组
    """
    df = pd.read_csv(csv_path)
    if index_col is not None:
        names = df[index_col].tolist()
        feats = df.drop(columns=[index_col]).values.astype(np.float32)
    else:
        names = df.index.tolist()
        feats = df.values.astype(np.float32)

    # 只取最后四列
    feats_last4 = feats[:, -4:]
    return names, feats_last4

def parse_floats(s):
    """将逗号分隔的字符串转为 float 数组"""
    return np.array([float(x) for x in s.split(',')], dtype=np.float32)

def match_top_k_last4(pred_feat, lib_last4, top_k=5):
    """
    只用最后四维，计算欧氏距离并返回 Top‑k。
    pred_feat: (4,)
    lib_last4: (N,4)
    """
    diff = lib_last4 - pred_feat[np.newaxis, :]  # (N,4)
    dists = np.linalg.norm(diff, axis=1)         # (N,)
    idx = np.argsort(dists)[:top_k]
    return idx, dists[idx]

def main():
    parser = argparse.ArgumentParser(
        description="只用 CSV 的最后四列特征，欧氏距离匹配音频库"
    )
    parser.add_argument('--audio_csv', required=True,
                        help='音频特征 CSV 文件（至少有四列，最后四列为目标特征）')
    parser.add_argument('--pred_feat', required=True,
                        help='预测特征，用逗号分隔，至少10个值，但只取最后4个')
    parser.add_argument('--top_k', type=int, default=5,
                        help='返回 Top‑K 匹配结果')
    parser.add_argument('--index_col', default=None,
                        help='可选，CSV 中用作名称的列名或列号')
    args = parser.parse_args()

    # 解析预测特征
    full_pred = parse_floats(args.pred_feat)
    if full_pred.size < 4:
        raise ValueError("pred_feat 至少需要 4 维")
    pred_last4 = full_pred[-4:]

    # 加载库中最后四列特征
    names, lib_last4 = load_last4_features(args.audio_csv, args.index_col)

    # 匹配 Top‑K
    topk_idx, topk_dists = match_top_k_last4(pred_last4, lib_last4, top_k=args.top_k)

    # 打印结果
    print(f"使用全部特征 = {pred_last4}")
    print(f"距离度量: Euclidean")
    print(f"\nTop-{args.top_k} 匹配结果：")
    for rank, (i, dist) in enumerate(zip(topk_idx, topk_dists), start=1):
        key = names[i]
        print(f"  {rank}. 索引/名称: {key}   距离: {dist:.4f}")

if __name__ == "__main__":
    main()
